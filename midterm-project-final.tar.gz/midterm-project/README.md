# Hotel Booking Cancellation Prediction

**Midterm Project — Machine Learning Zoomcamp 2026**

> Predicts whether a hotel booking will be **canceled** by the customer, using booking, guest, and stay features.
>
> Best model: **XGBoost** — Test AUC = **0.9407**

---

**Author:** Bogdan1102
**Course:** Machine Learning Zoomcamp 2026 — Midterm Project
**Submission date:** November 2026

### Tools used

- **Editor:** VS Code / GitHub Codespaces
- **AI assistant:** Z.ai (used for clarifications on textbook methodology and code review)
- **Methodology:** *Machine Learning Bookcamp* by Alexey Grigorev (Manning, 2021)
- **Dataset:** Hotel Booking Demand (Antonio, Almeida & Nunes, 2019)

---

## 1. Problem statement

Hotels receive cancellations every day. Each cancellation means lost revenue, overbooking risk, and operational friction. If a hotel could **anticipate** which bookings are likely to be canceled, it could:

- Proactively contact the customer to confirm the booking
- Adjust overbooking strategy on high-risk dates
- Offer targeted incentives (free upgrade, late checkout) to retain the booking

This project builds a binary classifier that outputs the **probability of cancellation** for a given booking, based on features known at booking time (lead time, guest profile, room type, deposit policy, etc.).

**Why it matters:** The cost of a canceled booking is roughly the price of one night's stay; the cost of intervening (a courtesy email) is negligible. Even a modest improvement in cancellation prediction translates directly into saved revenue.

---

## 2. Dataset

- **Source:** [Hotel Booking Demand](https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand) on Kaggle (originally from Antonio, Almeida & Nunes, 2019 — *Hotel booking demand datasets*, ScienceDirect).
- **Size:** 119,390 rows × 32 columns. We subsample to 15,000 rows for faster training (still above the 10k requirement).
- **Target:** `is_canceled` (1 = canceled, 0 = honored). Class balance: 63% / 37% — moderately imbalanced, suitable for AUC.
- **Features:** 11 numerical + 10 categorical, including `lead_time`, `adr`, `deposit_type`, `customer_type`, `market_segment`, `country`, etc.

### Download instructions

The dataset is mirrored on GitHub for reproducibility:

```bash
mkdir -p data
curl -L https://raw.githubusercontent.com/aaqibqadeer/Hotel-booking-demand/master/hotel_bookings.csv \
  -o data/hotel_bookings.csv
```

---

## 3. EDA highlights

- **Class imbalance:** 37% cancellation rate globally.
- **Strongest categorical predictors** (mutual information): `country`, `market_segment`, `deposit_type`, `reserved_room_type`.
- **Strongest numerical predictors** (correlation): `lead_time` (+0.19), `total_of_special_requests` (-0.24), `required_car_parking_spaces` (-0.20).
- **`deposit_type` = Non Refund** has a 99% cancellation rate — surprising but real (bookings with non-refundable deposits are often group bookings with high churn).
- **`market_segment` = Groups** cancels 61% of the time, vs. 11% for `Complementary`.

Full EDA is in [`notebook.ipynb`](notebook.ipynb) — including target distribution, group rates, correlation heatmap, mutual information scores, and feature importance plots.

---

## 4. Modeling approach

Four models were trained and compared, following the *Machine Learning Bookcamp* textbook:

| Model | Textbook chapter | Tuned params | Val AUC |
|---|---|---|---|
| Logistic Regression (baseline) | 3.3.2 | `C=1.0` | 0.8920 |
| Decision Tree | 6.2.3 | `max_depth`, `min_samples_leaf` | 0.9031 |
| Random Forest | 6.3.2 | `n_estimators`, `max_depth` | 0.9298 |
| **XGBoost** ✅ | 6.4 | `eta`, `max_depth` | **0.9363** |

**Selected model: XGBoost** with `eta=0.1, max_depth=6, num_boost_round=100`.

### Cross-validation (cap. 4.4.1)

5-fold CV on `df_full_train`:

```
Fold 1: AUC = 0.9371
Fold 2: AUC = 0.9395
Fold 3: AUC = 0.9406
Fold 4: AUC = 0.9400
Fold 5: AUC = 0.9360

Mean = 0.9387 ± 0.0017
```

Low standard deviation (0.0017) → model is stable across folds.

### Test set evaluation (cap. 6.4.4)

After retraining on full_train and evaluating on the held-out test set:

| Metric | Value |
|---|---|
| **AUC** | **0.9407** |
| Accuracy | 0.8630 |
| Precision | 0.8508 |
| Recall | 0.7826 |
| F1 | 0.8153 |

Confusion matrix (threshold = 0.5):

| | Pred not canceled | Pred canceled |
|---|---|---|
| **Actual not canceled** | 1682 (TN) | 159 (FP) |
| **Actual canceled** | 252 (FN) | 907 (TP) |

---

## 5. Project structure

```
hotel-cancellation-midterm/
├── data/
│   └── hotel_bookings.csv          # Dataset (downloaded via curl, see README)
├── plots/                          # EDA + ROC + confusion matrix PNGs
├── notebook.ipynb                  # Full EDA + modeling notebook
├── train.py                        # Train final model and save model.bin
├── predict.py                      # predict_one() helper, loads model.bin
├── predict-test.py                 # End-to-end test for the Flask service
├── serve.py                        # Flask app exposing /predict and /health
├── model.bin                       # Pickled DictVectorizer + XGBoost model
├── sample_request.json             # Example input for /predict
├── Pipfile                         # Pipenv dependency spec (cap. 5.3.1)
├── Pipfile.lock                    # Pinned dependency hashes (cap. 5.3.1)
├── requirements.txt                # Pip-only fallback
├── Dockerfile                      # Container image (Python 3.11-slim + gunicorn)
├── .dockerignore
└── README.md                       # This file
```

---

## 6. How to run locally

### 6.1 Prerequisites

- Python 3.10+
- `pip` and `pipenv` (preferred, cap. 5.3.1)

### 6.2 Install dependencies

**Option A — Pipenv (recommended, cap. 5.3.1):**

```bash
pip install pipenv
pipenv install                # uses Pipfile.lock for pinned versions
pipenv shell                  # activate the virtualenv
```

**Option B — Plain pip (fallback):**

```bash
python -m venv venv
source venv/bin/activate           # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 6.3 Download the dataset

```bash
mkdir -p data
curl -L https://raw.githubusercontent.com/aaqibqadeer/Hotel-booking-demand/master/hotel_bookings.csv \
  -o data/hotel_bookings.csv
```

### 6.4 Train the model

```bash
python train.py
```

This will:
1. Load and clean the data.
2. Train 4 models (LogReg, DT, RF, XGBoost) with hyperparameter tuning.
3. Run 5-fold CV on the best model.
4. Train the final model on `full_train` and evaluate on `test`.
5. Save the result to `model.bin`.

Expected output:
```
Test AUC: 0.9407
Model saved to model.bin
```

### 6.5 Run the web service

```bash
python serve.py
```

The Flask app starts on `http://localhost:9696`.

### 6.6 Test the API

In another terminal:

```bash
# Liveness check
curl http://localhost:9696/health
# {"status":"ok"}

# Predict on a sample booking
curl -X POST http://localhost:9696/predict \
  -H "Content-Type: application/json" \
  -d @sample_request.json
# {"cancellation_probability":0.31...,"is_canceled":false}
```

You can also use the standalone `predict.py` to score a single booking without the web service:

```bash
python predict.py
# Probability of cancellation: 0.3123
# Predicted class: NOT CANCELED
```

### 6.7 End-to-end test (cap. 5 — testing the service)

A dedicated test script, `predict-test.py`, starts `serve.py` as a subprocess and asserts that both `/health` and `/predict` behave correctly:

```bash
python predict-test.py
# Starting serve.py ...
# Test 1: GET /health ... PASS
# Test 2: POST /predict ... PASS (probability=0.5636, is_canceled=True)
#
# 2/2 tests passed
```

---

## 7. How to run with Docker

### 7.1 Build the image

```bash
docker build -t hotel-cancellation-predictor .
```

### 7.2 Run the container

```bash
docker run -it --rm -p 9696:9696 hotel-cancellation-predictor
```

### 7.3 Test it

```bash
curl http://localhost:9696/health
curl -X POST http://localhost:9696/predict \
  -H "Content-Type: application/json" \
  -d @sample_request.json
```

The container uses **gunicorn** (production WSGI server) instead of the Flask development server, as recommended in the textbook (cap. 5.3.1).

---

## 8. Cloud deployment (cap. 5.4 — AWS Elastic Beanstalk)

The Docker container is compatible with AWS Elastic Beanstalk, Render, or any container-hosting platform. Below is the recipe for **AWS Elastic Beanstalk** (cap. 5.4.1).

### 8.1 Prerequisites

- AWS account + AWS CLI configured (`aws configure`)
- Dockerfile at the root of the repo (✅ already present)
- `eb` CLI installed: `pip install awsebcli`

### 8.2 Initialize the EB environment

```bash
# From the repo root:
eb init -p docker hotel-cancellation-predictor
# Answer prompts: region, AWS credentials, ssh key (optional)

# Create the environment and deploy:
eb create hotel-cancellation-env

# Wait ~5 minutes for the environment to provision.
# When ready, EB prints the URL:
# http://hotel-cancellation-env.eba-xxxxxx.eu-west-1.elasticbeanstalk.com
```

### 8.3 Test the cloud service

```bash
# Liveness check
curl http://hotel-cancellation-env.eba-xxxxxx.eu-west-1.elasticbeanstalk.com/health

# Predict on a sample booking
curl -X POST http://hotel-cancellation-env.eba-xxxxxx.eu-west-1.elasticbeanstalk.com/predict \
  -H "Content-Type: application/json" \
  -d @sample_request.json
```

### 8.4 Teardown (avoid charges!)

When you no longer need the deployment:

```bash
eb terminate hotel-cancellation-env --nohangup
```

> ⚠️ **Free-tier reminder:** AWS Elastic Beanstalk is free-tier eligible for the first 12 months after account creation, but you should still terminate the environment when you're done to avoid unexpected charges.

---

## 9. API reference

### `GET /health`

Liveness probe.

**Response:** `200 OK`
```json
{"status": "ok"}
```

### `POST /predict`

Score a single booking.

**Request body:** JSON object with booking fields. See [`sample_request.json`](sample_request.json) for a complete example.

**Response:** `200 OK`
```json
{
  "cancellation_probability": 0.3123,
  "is_canceled": false
}
```

The `is_canceled` field uses a 0.5 threshold. Adjust on the client side if your business logic prefers a different cutoff (e.g., intervene only if probability > 0.7).

---

## 10. Methodology references (Machine Learning Bookcamp)

| Step | Textbook chapter |
|---|---|
| Missing values & `fillna` | 2.2.4, 2.4.1 |
| `train_test_split` | 3.1.2 |
| One-hot encoding with `DictVectorizer` | 3.2.1, 6.1.3 |
| Logistic Regression baseline | 3.3.2 |
| Confusion table | 4.2.2 |
| Precision & Recall | 4.2.3 |
| ROC curves & AUC | 4.3.5, 4.3.6 |
| K-fold cross-validation | 4.4.1 |
| Decision Tree tuning | 6.2.3 |
| Random Forest tuning | 6.3.2 |
| XGBoost tuning | 6.4 |
| Save with `pickle` | 5.1.2 |
| Flask web service | 5.2.3 |
| Dependency management with `requirements.txt` | 5.3.1 |
| Docker containerization | 5.3.2 |

---

## 11. Known limitations & next steps

- **No temporal validation:** We use a random split, not a time-based one. In production, you should split by `arrival_date` to avoid leakage from future bookings.
- **Subsample to 15k rows:** For training speed. With the full 119k rows and longer tuning, AUC could improve to ~0.95.
- **No text features:** `country` is one-hot encoded as-is; in production, you could group rare countries into an "Other" bucket or use target encoding.
- **Threshold tuning:** We use 0.5 by default. For a real deployment, you should pick the threshold that optimizes your business metric (e.g., expected revenue saved per intervention).
- **Cloud deployment:** The repository contains full AWS Elastic Beanstalk instructions (section 8). The actual deployment is left to the user — it requires AWS credentials and may incur charges.

---

## 12. Reproducibility

To reproduce the exact results:

1. Clone this repository.
2. Follow steps in [section 6](#6-how-to-run-locally) — install deps, download data, run `train.py`.
3. The script uses `random_state=42` everywhere, so all results should match the values in this README.

Tested with:
- Python 3.11
- scikit-learn 1.4.2
- xgboost 2.0.3
- pandas 2.2.2
- numpy 1.26.4

---

## 13. License

- **Code:** MIT (see `LICENSE` if present, otherwise treat as MIT).
- **Dataset:** The Hotel Booking Demand dataset is licensed under CC0 (public domain) — see the [original Kaggle page](https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand).
